const express = require('express');
const router = express.Router();
const pool = require('../db');

/**
 * GET /api/products
 *
 * Query params:
 *   category   - filter by category name (optional)
 *   limit      - page size, default 20, max 100
 *   cursor     - opaque cursor from previous response (for next page)
 *
 * Cursor-based pagination strategy:
 *   We sort by (created_at DESC, id DESC) — this is a stable, unique sort order.
 *   The cursor encodes the (created_at, id) of the last item seen.
 *   This means even if new rows are inserted, the user never sees duplicates
 *   or skips rows — unlike OFFSET which shifts with insertions.
 */
router.get('/', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const category = req.query.category || null;
    const cursorParam = req.query.cursor || null;

    // Decode cursor: base64-encoded JSON {created_at, id}
    let cursorCreatedAt = null;
    let cursorId = null;

    if (cursorParam) {
      try {
        const decoded = JSON.parse(Buffer.from(cursorParam, 'base64').toString('utf8'));
        cursorCreatedAt = decoded.created_at;
        cursorId = decoded.id;
      } catch {
        return res.status(400).json({ error: 'Invalid cursor' });
      }
    }

    // Build query dynamically
    const values = [];
    let idx = 1;

    let whereClause = '';
    const conditions = [];

    // Category filter
    if (category) {
      conditions.push(`category = $${idx++}`);
      values.push(category);
    }

    // Cursor condition: fetch rows "after" the cursor position
    // (created_at, id) DESC means: older created_at OR same created_at but smaller id
    if (cursorCreatedAt && cursorId) {
      conditions.push(
        `(created_at < $${idx} OR (created_at = $${idx} AND id < $${idx + 1}))`
      );
      values.push(cursorCreatedAt, cursorId);
      idx += 2;
    }

    if (conditions.length > 0) {
      whereClause = 'WHERE ' + conditions.join(' AND ');
    }

    values.push(limit + 1); // fetch one extra to detect if there's a next page
    const limitPlaceholder = `$${idx}`;

    const query = `
      SELECT id, name, category, price, updated_at, created_at
      FROM products
      ${whereClause}
      ORDER BY created_at DESC, id DESC
      LIMIT ${limitPlaceholder}
    `;

    const result = await pool.query(query, values);
    const rows = result.rows;

    const hasNextPage = rows.length > limit;
    const items = hasNextPage ? rows.slice(0, limit) : rows;

    // Encode next cursor from last item
    let nextCursor = null;
    if (hasNextPage) {
      const last = items[items.length - 1];
      nextCursor = Buffer.from(
        JSON.stringify({ created_at: last.created_at, id: last.id })
      ).toString('base64');
    }

    res.json({
      data: items,
      pagination: {
        limit,
        has_next_page: hasNextPage,
        next_cursor: nextCursor,
      },
    });
  } catch (err) {
    console.error('GET /products error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /api/products/categories
 * Returns all distinct categories (cached-friendly, rarely changes)
 */
router.get('/categories', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT category, COUNT(*) as count FROM products GROUP BY category ORDER BY category'
    );
    res.json({ data: result.rows });
  } catch (err) {
    console.error('GET /categories error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * GET /api/products/:id
 * Fetch a single product by ID
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (isNaN(parseInt(id))) {
      return res.status(400).json({ error: 'Invalid product id' });
    }
    const result = await pool.query('SELECT * FROM products WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ data: result.rows[0] });
  } catch (err) {
    console.error('GET /products/:id error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
