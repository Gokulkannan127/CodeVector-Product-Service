require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./db');
const productsRouter = require('./routes/products');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Health check — Render uses this to confirm the app is alive
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'connected' });
  } catch (err) {
    res.status(500).json({ status: 'error', db: 'disconnected' });
  }
});

app.get('/', (req, res) => {
  res.json({
    name: 'CodeVector Products API',
    version: '1.0.0',
    endpoints: {
      products: 'GET /api/products?category=Electronics&limit=20&cursor=<cursor>',
      categories: 'GET /api/products/categories',
      single: 'GET /api/products/:id',
      health: 'GET /health',
    },
  });
});

app.use('/api/products', productsRouter);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
