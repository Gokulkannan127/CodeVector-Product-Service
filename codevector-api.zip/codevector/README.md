# CodeVector Products API

A fast backend to browse ~200,000 products with category filtering and stable cursor-based pagination.

## Tech Stack

- **Runtime**: Node.js + Express
- **Database**: PostgreSQL (Neon / Supabase free tier)
- **Hosting**: Render (free web service)

---

## Local Setup

```bash
# 1. Install dependencies
npm install

# 2. Create .env from template
cp .env.example .env
# → Edit .env and set DATABASE_URL to your Neon/Supabase connection string

# 3. Seed the database (one-time, ~30-60s for 200k rows)
npm run seed

# 4. Start the server
npm run dev   # development (auto-reload)
npm start     # production
```

---

## Deploy to Render (free, no credit card)

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your repo
4. Set these:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Environment Variable**: `DATABASE_URL` = your Neon/Supabase URL
5. Deploy — Render gives you a public HTTPS URL

**Database (Neon — free, no credit card):**
1. Go to [neon.tech](https://neon.tech) → New Project
2. Copy the connection string → paste into `DATABASE_URL`
3. Run `npm run seed` once to populate 200k rows

---

## API Reference

### `GET /api/products`

Browse products, newest first. Supports category filter and cursor pagination.

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `category` | string | – | Filter by category name |
| `limit` | number | 20 | Page size (max 100) |
| `cursor` | string | – | Opaque cursor from previous response |

**Example:**
```
GET /api/products?category=Electronics&limit=20
GET /api/products?category=Electronics&limit=20&cursor=eyJjcmVh...
```

**Response:**
```json
{
  "data": [
    {
      "id": 199532,
      "name": "Ultra Gadget 199532",
      "category": "Electronics",
      "price": "349.99",
      "updated_at": "2025-11-03T10:22:00.000Z",
      "created_at": "2025-11-03T10:22:00.000Z"
    }
  ],
  "pagination": {
    "limit": 20,
    "has_next_page": true,
    "next_cursor": "eyJjcmVhdGVkX2F0IjoiMjAyNS0xMS0wM1QxMDoyMjowMC4wMDBaIiwiaWQiOjE5OTUzMn0="
  }
}
```

To get the next page, pass `next_cursor` as the `cursor` param in the next request.

---

### `GET /api/products/categories`

Returns all categories with product counts.

```json
{
  "data": [
    { "category": "Electronics", "count": "20134" },
    { "category": "Clothing",    "count": "19876" }
  ]
}
```

---

### `GET /api/products/:id`

Fetch a single product by its ID.

---

### `GET /health`

Returns `{ "status": "ok", "db": "connected" }` — used by Render for health checks.

---

## Design Decisions

### Why cursor-based pagination (not OFFSET)?

The task says:
> "If 50 new products are added/updated while someone is browsing, they must not see the same product twice or miss one."

**OFFSET pagination breaks when data changes:**
- Page 1: `OFFSET 0 LIMIT 20` → rows 1–20
- 5 new rows inserted
- Page 2: `OFFSET 20 LIMIT 20` → rows 26–45 (rows 21–25 are skipped!)

**Cursor pagination is stable:**
- We sort by `(created_at DESC, id DESC)` — a unique, immutable sort key
- The cursor encodes `{created_at, id}` of the last item seen
- The next page query is: `WHERE (created_at < cursor_ts OR (created_at = cursor_ts AND id < cursor_id))`
- New inserts are **always newer** so they appear at the front of the list — they never shift existing pages

### Why `pg COPY` for seeding?

`COPY` streams tab-separated text directly into Postgres — ~10–50x faster than individual `INSERT` statements. 200k rows in ~30s instead of several minutes.

### Why `(created_at DESC, id DESC)` index?

Covers both the unfiltered browse and the category-filtered browse (with the separate `category, created_at DESC, id DESC` partial index). Postgres can satisfy `ORDER BY created_at DESC, id DESC` with index scans — no sequential scan on 200k rows.
