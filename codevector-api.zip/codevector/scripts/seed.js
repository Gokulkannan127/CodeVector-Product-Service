/**
 * Seed script: generates 200,000 products fast using pg COPY via stdin stream.
 * COPY is orders of magnitude faster than INSERT in a loop.
 *
 * Usage:
 *   DATABASE_URL=your_url node scripts/seed.js
 */

require('dotenv').config();
const { Client } = require('pg');
const { Readable } = require('stream');
const { from: copyFrom } = require('pg-copy-streams');

const TOTAL = 200_000;
const BATCH_SIZE = 10_000;

const CATEGORIES = [
  'Electronics',
  'Clothing',
  'Books',
  'Home & Garden',
  'Sports',
  'Toys',
  'Automotive',
  'Health & Beauty',
  'Food & Grocery',
  'Office Supplies',
];

const ADJECTIVES = [
  'Premium', 'Deluxe', 'Pro', 'Lite', 'Ultra', 'Mini', 'Max', 'Smart',
  'Classic', 'Advanced', 'Essential', 'Elite', 'Basic', 'Compact', 'Turbo',
];

const NOUNS = [
  'Widget', 'Gadget', 'Device', 'Tool', 'Kit', 'Pack', 'Set', 'Bundle',
  'Unit', 'Module', 'System', 'Solution', 'Item', 'Product', 'Accessory',
];

function randomElement(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomPrice() {
  return (Math.random() * 999 + 1).toFixed(2);
}

// Returns a random timestamp spread over the last 2 years (for realistic distribution)
function randomTimestamp(base) {
  const twoYearsMs = 2 * 365 * 24 * 60 * 60 * 1000;
  return new Date(base - Math.floor(Math.random() * twoYearsMs)).toISOString();
}

async function createTable(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS products (
      id          BIGSERIAL PRIMARY KEY,
      name        TEXT        NOT NULL,
      category    TEXT        NOT NULL,
      price       NUMERIC(10,2) NOT NULL,
      updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);

  // Index for our cursor pagination sort order + category filter
  await client.query(`
    CREATE INDEX IF NOT EXISTS idx_products_created_at_id
      ON products (created_at DESC, id DESC);
  `);

  await client.query(`
    CREATE INDEX IF NOT EXISTS idx_products_category_created_at_id
      ON products (category, created_at DESC, id DESC);
  `);

  console.log('✓ Table and indexes ready');
}

async function seedViaCopy(client) {
  const now = Date.now();
  let inserted = 0;

  while (inserted < TOTAL) {
    const count = Math.min(BATCH_SIZE, TOTAL - inserted);

    // Build TSV rows for COPY
    const rows = [];
    for (let i = 0; i < count; i++) {
      const name = `${randomElement(ADJECTIVES)} ${randomElement(NOUNS)} ${inserted + i + 1}`;
      const category = randomElement(CATEGORIES);
      const price = randomPrice();
      const createdAt = randomTimestamp(now);
      const updatedAt = createdAt; // same for seed data
      // TSV: tab-separated, \n newline. Escape tabs/newlines in text just in case.
      rows.push(`${name}\t${category}\t${price}\t${updatedAt}\t${createdAt}`);
    }

    const tsv = rows.join('\n') + '\n';

    await new Promise((resolve, reject) => {
      const stream = client.query(
        copyFrom('COPY products (name, category, price, updated_at, created_at) FROM STDIN WITH (FORMAT text)')
      );
      stream.on('finish', resolve);
      stream.on('error', reject);

      const readable = Readable.from([tsv]);
      readable.pipe(stream);
    });

    inserted += count;
    process.stdout.write(`\r  Inserted ${inserted.toLocaleString()} / ${TOTAL.toLocaleString()}`);
  }

  console.log('\n✓ All rows inserted');
}

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error('ERROR: DATABASE_URL environment variable is not set.');
    console.error('Copy .env.example to .env and fill in your Neon/Supabase connection string.');
    process.exit(1);
  }

  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  try {
    console.log('Connecting to database...');
    await client.connect();
    console.log('✓ Connected');

    await createTable(client);

    const { rows } = await client.query('SELECT COUNT(*) as count FROM products');
    const existing = parseInt(rows[0].count);
    if (existing > 0) {
      console.log(`Database already has ${existing.toLocaleString()} products. Skipping seed.`);
      console.log('To re-seed, run: DELETE FROM products; then run this script again.');
      return;
    }

    console.log(`Seeding ${TOTAL.toLocaleString()} products using COPY (fast bulk insert)...`);
    const start = Date.now();
    await seedViaCopy(client);
    const elapsed = ((Date.now() - start) / 1000).toFixed(1);
    console.log(`✓ Done in ${elapsed}s`);

  } catch (err) {
    console.error('Seed error:', err.message);
    process.exit(1);
  } finally {
    await client.end();
  }
}

main();
